using YamlDotNet.Core.Tokens;

var builder = DistributedApplication.CreateBuilder(args);

var AiConnectionString = builder.AddParameter("AiConnectionString", secret: true);
var AzTenantId = builder.AddParameter("AzTenantId", secret: true);
var AzClientSecret = builder.AddParameter("AzClientSecret", secret: true);
var AzClientId = builder.AddParameter("AzClientId", secret: true);


builder.AddProject<Projects.AcApi>("AcApi")
    .WithEnvironment("APPLICATIONINSIGHTS_CONNECTION_STRING", AiConnectionString)
    .WithEnvironment("AZURE_CLIENT_SECRET", AzClientSecret)
    .WithEnvironment("AZURE_CLIENT_ID", AzClientId)
    .WithEnvironment("AZURE_TENANT_ID", AzTenantId)
    .WithEnvironment("OTEL_RESOURCE_ATTRIBUTES", "service.name=AcApi,service.namespace=test.namespace,service.version=0.9");

builder.Build().Run();