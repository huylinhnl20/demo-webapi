Git branch master created successfully!

curl -kv -X post https://localhost:8443/api/management/force-gc

        "Console": {
          "FormatterName": "simple",
          "FormatterOptions": {
            "SingleLine": true,
            "IncludeScopes": true,
            "TimestampFormat": "yyyy-MM-dd HH:mm:ss ",
            "UseUtcTimestamp": false
          }
        }