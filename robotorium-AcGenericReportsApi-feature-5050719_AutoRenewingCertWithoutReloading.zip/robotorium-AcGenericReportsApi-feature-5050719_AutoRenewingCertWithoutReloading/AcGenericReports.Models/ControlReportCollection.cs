﻿using System.Net.NetworkInformation;

namespace AcGenericReports.Models;
/// <summary>
/// This object stores all the collected reports for a certaint ci within a platform for a certain control.
/// 
/// Example: Ci with id 1234 for the platform Nexpose and control number 113
/// </summary>
public class ControlReportCollection
{
    /// <summary>
    /// Generic constructor used to create a new ControlReportCollection, this wil initialize an empty Controls list
    /// </summary>
    /// <param name="resourceId">The id for the CI as stated in the UCMDB</param>
    /// <param name="platform">name of the platform/application the checks are performed on</param>
    /// <param name="control">The number of the control which are the subject of the reports</param>
    public ControlReportCollection(string resourceId, string platform, int control)
    {
        ResourceId = resourceId;
        Platform = platform;
        Control = control;
        Controls = new List<ControlDTO>();
    }

    public ControlReportCollection()
    {

    }

    /// <summary>
    /// The id for the CI as stated in the UCMDB.
    /// </summary>
    public string ResourceId {get; set;}
    /// <summary>
    /// Name of the platform/application the checks are performed on.
    /// </summary>
    public string Platform {get; set;}

    /// <summary>
    ///The number of the control which are the subject of the reports.
    /// </summary>
    public int Control {get; set;}
    
    /// <summary>
    /// The collection of the control DTO.
    /// </summary>
    public List<ControlDTO> Controls {get; set;}

    public void AddControl(ControlDTO control){

        var index = this.Controls.FindIndex(c => c.Date == control.Date);
        if(index > -1)
        {
            this.Controls[index] = control;
        }
        else
        {
            this.Controls.Add(control);
        }
    }
}
