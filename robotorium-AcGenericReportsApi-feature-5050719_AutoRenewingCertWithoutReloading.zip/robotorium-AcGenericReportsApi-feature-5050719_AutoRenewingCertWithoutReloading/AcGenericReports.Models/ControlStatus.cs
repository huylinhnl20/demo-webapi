﻿namespace AcGenericReports.Models;

/// <summary>
/// Enumeration representing the status of a controll with thier corresponding codes
/// 
/// Compliant = 1 <br />
/// Not Compliant = 2 <br />
/// Error codes = the codes 3,4 and 5 represents an error code generated during the copliancy check respected error codes are:
///     <ul>
///     <li> Technical Error: Any techinical issue may have risen during the check </li>
///     <li>Connection error: Connection to the platform system could not be made </li>
///     <li>Authentication error: the check mechanismn was not able to authenticate itself at the platform </li>
///    </ul>
/// Non compliant RSLO = 6 if the control is not compliant by RSLO
/// </summary>
public enum ControlStatus
{
    Compliant = 1,
    NonCompliant = 2,
    TechnicalError = 3,
    ConncectionError = 4,
    AuthError = 5,
    NonCompliantRSLO = 6
}
