﻿using System.ComponentModel.DataAnnotations;
namespace AcGenericReports.Models;

/// <summary>
/// ControlDTO represents the compliancy reports that will be consumed by the Automated controls 
/// </summary>
public class ControlDTO : ControlReportDTO
{
    /// <summary>
    /// The date of when the ControlDTO was being processed by the Api, default format YYYY-MM-dd
    /// </summary>
    [Required]
    public DateOnly Date {get; set;}
}
