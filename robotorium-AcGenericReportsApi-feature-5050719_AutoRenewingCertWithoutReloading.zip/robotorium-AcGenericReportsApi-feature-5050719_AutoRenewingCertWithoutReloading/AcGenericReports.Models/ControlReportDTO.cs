﻿using System.ComponentModel.DataAnnotations;

namespace AcGenericReports.Models;

/// <summary>
/// ControlReportDTO's are profided by the platforms. 
/// It reports the compliantcy status of a certain control for a certain resource within a platform.
/// </summary>
public class ControlReportDTO
{
    /// <summary>
    /// The identification number of the control
    /// </summary>
    [Required]
    public int Control {get; set;}

    /// <summary>
    /// The status of the checked control
    /// </summary>
    [Required]
    public ControlStatus Status {get; set;}
    /// <summary>
    /// The id of the CI as stated in the UCMDB 
    /// </summary>
    [Required]
    public string ResourceId {get; set;}
    /// <summary>
    /// The platform group which the ci and control belongs to e.g Nexpose 
    /// </summary>
    [Required]
    public string Platform {get; set;}
    /// <summary>
    /// Optional information that the platform can provide with the report e.g. 
    /// extra information on an error 
    /// </summary>
    public string Info {get; set;}
}
