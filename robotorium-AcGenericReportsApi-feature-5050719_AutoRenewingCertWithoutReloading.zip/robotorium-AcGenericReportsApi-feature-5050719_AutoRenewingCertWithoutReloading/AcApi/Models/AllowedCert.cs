﻿using System.ComponentModel;

namespace AcApi.Models
{
    public class AllowedCert
    {
        [DefaultValue("[Department] & [Application]")] 
        public required string Name { get; set; }
        [DefaultValue("Common Name")] 
        public required string CN { get; set; }
        [DefaultValue(false)]
        public bool IsApiAdmin { get; set; } = false;
    }
}
