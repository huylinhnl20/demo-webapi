﻿namespace AcApi.Models
{
    public class CertOptions
    {
        public IEnumerable<AllowedCert> AllowedCerts { get; set; }
    }
}
