﻿using AcApi.Models;
using Microsoft.Extensions.Options;
using System.Security.Cryptography.X509Certificates;

namespace AcApi.Services
{
    public class CertificateValidationService
    {
        private readonly CertOptions certOptions;
        private readonly ILogger _logger;

        public CertificateValidationService(IOptionsMonitor<CertOptions> options,
                                            ILogger<CertificateValidationService> logger)
        {
            certOptions = options.CurrentValue;
            _logger = logger;
        }

        public AllowedCert ValidateCertificate(X509Certificate2 certificate)
        {
            string subject = certificate.Subject;
            string certificateCN = subject!.Split(',')!.FirstOrDefault(s => s.StartsWith("CN=",
                StringComparison.OrdinalIgnoreCase))!.Trim().Substring(3);

            var allowedCert = certOptions.AllowedCerts.FirstOrDefault(ac => ac.CN.ToLower() == certificateCN.ToLower());

            if (allowedCert != null)
            {
                _logger.LogTrace($"auth successful for CN: {certificateCN}, Name:{allowedCert.Name}");
                return allowedCert;
            }
            _logger.LogWarning($"auth rejected for CN: {certificateCN}");
            return allowedCert;
        }

        public bool IsApiAdmin(AllowedCert allowedCert)
        {
            if (allowedCert.IsApiAdmin)
            {
                _logger.LogTrace($"CN: {allowedCert.CN}, IsApiAdmin: true)");
                return true;
            }
            _logger.LogTrace($"CN: {allowedCert.CN}, IsApiAdmin: false)");

            return false;
        }
    }
}
