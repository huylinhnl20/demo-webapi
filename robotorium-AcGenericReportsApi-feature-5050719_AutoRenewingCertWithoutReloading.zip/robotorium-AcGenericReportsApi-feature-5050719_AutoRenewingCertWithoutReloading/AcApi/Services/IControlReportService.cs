﻿using AcGenericReports.Models;

namespace AcApi.Services;

public interface IControlReportService
{
    Task ProcessDataAsync(ControlReportDTO controlReportDTO);
    Task<ControlReportCollection> GetDataAsync(string platform, string resourceId, int control);
}