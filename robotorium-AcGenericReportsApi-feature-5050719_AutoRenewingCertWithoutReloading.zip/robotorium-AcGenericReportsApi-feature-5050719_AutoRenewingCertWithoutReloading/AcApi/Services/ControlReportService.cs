﻿using AcApi.Adapters;
using AcGenericReports.Models;

namespace AcApi.Services;

public class ControlReportService : IControlReportService
{
    private readonly IStorageAdapter _storageAdapter;
    private readonly ILogger<IControlReportService> _logger;
  
    public ControlReportService(IStorageAdapter storageAdapter,
                                ILogger<IControlReportService> logger)
    {
        _storageAdapter = storageAdapter;
        _logger = logger;
    }

    public async Task<ControlReportCollection> GetDataAsync(string platform, string resourceId, int control)
    {
        return await _storageAdapter.ReadData(platform, resourceId, control);
    }

    public async Task ProcessDataAsync(ControlReportDTO controlReportDTO)
    {
        ControlDTO controlDTO = new()
        {
            Date = DateOnly.FromDateTime(DateTime.Now),
            Info = controlReportDTO.Info,
            Platform = controlReportDTO.Platform,
            ResourceId = controlReportDTO.ResourceId,
            Status = controlReportDTO.Status,
            Control = controlReportDTO.Control
        };
        var collection = await _storageAdapter.ReadData(controlDTO.Platform, controlDTO.ResourceId, controlDTO.Control);            

        if (collection == null)
        {
            _logger.LogInformation($"Creating new collection for Platform: '{controlReportDTO.Platform}', ResourceId: '{controlReportDTO.ResourceId}' and Control: '{controlReportDTO.Control}'");
            collection = new ControlReportCollection(controlDTO.ResourceId, controlDTO.Platform, controlDTO.Control);
        }
        collection.AddControl(controlDTO);
        _logger.LogInformation($"Add Control data to collection for Platform: '{controlReportDTO.Platform}', ResourceId: '{controlReportDTO.ResourceId}' and Control: '{controlReportDTO.Control}'");
        await _storageAdapter.WriteData(collection);
    }
}
