﻿using System.Security.Cryptography.X509Certificates;

namespace AcApi.Services;

public class CertificateWatcher
{
    private readonly string? _certPath;
    private readonly string? _certPassword;
    private X509Certificate2 _currentCertificate;
    private FileSystemWatcher _watcher;

    public CertificateWatcher(string certPath, 
                              string certPassword,
                              X509Certificate2 currentCertificate)
    {
        Console.WriteLine("Certificate file changed. Start...");
        _certPath = certPath;
        _certPassword = certPassword;
        _currentCertificate = currentCertificate;

        // Set up the file watcher
        var certFileWatcher = new FileSystemWatcher(Path.GetDirectoryName(certPath))
        {
            //NotifyFilter = NotifyFilters.LastWrite,
            Filter = Path.GetFileName(certPath)
        };

        certFileWatcher.Changed += OnCertificateChanged;
        certFileWatcher.EnableRaisingEvents = true;
        Console.WriteLine("Certificate file changed. Reloading...");
    }

    private void OnCertificateChanged(object sender, FileSystemEventArgs e)
    {
        Console.WriteLine("Certificate file changed. Reloading...");

        System.Threading.Thread.Sleep(1000);

        // Load the new certificate
        try
        {
            _currentCertificate = new X509Certificate2(_certPath!, _certPassword);
            Console.WriteLine("Certificate reloaded successfully.");
        }
        catch
        {
            Console.WriteLine("Failed to reload certificate.");
        }
    }
}
