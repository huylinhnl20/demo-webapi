﻿using Microsoft.AspNetCore.Server.Kestrel.Core;
using System.Security.Cryptography.X509Certificates;

namespace AcApi.Extensions;

public static class KestrelCertificateExtension
{

    public static void ConfigureKestrelWithCertificate(this WebApplicationBuilder builder, string path, string password)
    {
        X509Certificate2 currentCertificate = new X509Certificate2(path, password);

        // Configure Kestrel to use the certificate
        builder.Services.Configure<KestrelServerOptions>(serverOptions =>
        {
            serverOptions.ConfigureHttpsDefaults(listenOptions =>
            {
                listenOptions.ServerCertificateSelector = (context, name) => currentCertificate;
            });
        });

        builder.Services.AddSingleton(currentCertificate);
    }
}
