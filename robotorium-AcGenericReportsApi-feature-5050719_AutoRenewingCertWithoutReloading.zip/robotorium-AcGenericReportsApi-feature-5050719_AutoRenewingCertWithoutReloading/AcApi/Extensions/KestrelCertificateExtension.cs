﻿using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using System.Security.Cryptography.X509Certificates;
using AcApi.Services;

namespace AcApi.Extensions;

public static class KestrelCertificateExtension
{
    public static void ConfigureKestrelWithCertificate(this WebApplicationBuilder builder, string path, string password)
    {
        X509Certificate2 initialCertificate = new X509Certificate2(path, password);

        // Create and register the CertificateWatcher as a singleton
        var certificateWatcher = new CertificateWatcher(path, password, initialCertificate);
        builder.Services.AddSingleton(certificateWatcher);

        // Configure Kestrel to use the certificate from the watcher
        builder.WebHost.ConfigureKestrel((context, serverOptions) =>
        {
            serverOptions.ConfigureHttpsDefaults(httpsOptions =>
            {
                httpsOptions.ServerCertificateSelector = (connectionContext, name) => certificateWatcher.CurrentCertificate;
                httpsOptions.ClientCertificateMode = ClientCertificateMode.AllowCertificate;
            });
        });
    }
}
