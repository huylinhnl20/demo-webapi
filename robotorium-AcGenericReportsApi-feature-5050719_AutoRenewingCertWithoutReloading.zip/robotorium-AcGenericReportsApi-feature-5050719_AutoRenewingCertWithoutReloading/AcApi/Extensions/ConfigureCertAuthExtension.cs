﻿using AcApi.Models;
using AcApi.Services;
using Microsoft.AspNetCore.Authentication.Certificate;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;

namespace AcApi.Extensions
{
    public static class ConfigureCertAuthExtension
    {
        public static void ConfigureClientCertAuthentication(this IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiAdmin", policy =>
                    policy.RequireClaim("ApiAdmin"));
            });

            services.AddTransient<CertificateValidationService>();
            services.AddAuthentication(CertificateAuthenticationDefaults.AuthenticationScheme)
                .AddCertificate(options =>
                {
                    options.AllowedCertificateTypes = CertificateTypes.All;
                    options.ValidateCertificateUse = false;
                    options.RevocationMode = X509RevocationMode.NoCheck;
                    options.ValidateValidityPeriod = false;
                    options.Events = new CertificateAuthenticationEvents
                    {
                        OnCertificateValidated = context =>
                        {
                            var validationService = context.HttpContext.RequestServices.GetService<CertificateValidationService>();

                            AllowedCert allowedCert = validationService.ValidateCertificate(context.ClientCertificate);

                            if (allowedCert != null)
                            {
                                var claims = new List<Claim>
                                {
                                    new Claim(
                                        ClaimTypes.NameIdentifier,
                                        context.ClientCertificate.Subject,
                                        ClaimValueTypes.String, context.Options.ClaimsIssuer),
                                    new Claim(
                                        ClaimTypes.Name,
                                        context.ClientCertificate.Subject,
                                        ClaimValueTypes.String, context.Options.ClaimsIssuer),
                                };
                                if (validationService.IsApiAdmin(allowedCert))
                                {
                                    claims.Add(new Claim("apiadmin", "true"));
                                };

                                context.Principal = new ClaimsPrincipal(
                                    new ClaimsIdentity(claims, context.Scheme.Name));
                                context.Success();
                            }
                            else
                            {
                                context.Fail("invalid cert or no cert found");
                            }
                            return Task.CompletedTask;
                        },
                        OnAuthenticationFailed = context =>
                        {
                            return Task.CompletedTask;
                        },
                    };
                });
        }
    }
}
