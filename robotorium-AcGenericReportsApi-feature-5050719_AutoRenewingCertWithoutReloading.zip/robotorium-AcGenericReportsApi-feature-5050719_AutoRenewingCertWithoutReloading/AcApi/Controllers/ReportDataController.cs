﻿using AcApi.Services;
using Microsoft.AspNetCore.Authentication.Certificate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AcApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = CertificateAuthenticationDefaults.AuthenticationScheme)]
    public class ReportDataController : ControllerBase
    {
        private readonly IControlReportService _controlReportService;
        private readonly ILogger<ReportDataController> _logger;

        public ReportDataController(IControlReportService controlReportService,
                                    ILogger<ReportDataController> logger)
        {
            _controlReportService = controlReportService;
            _logger = logger;
        }

        [HttpGet("{platform}/{resourceId}/{control:int}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Get([FromRoute] string platform, [FromRoute] string resourceId, [FromRoute] int control)
        {
            _logger.LogInformation($"Grabbing Data for Platform: '{platform}', ResourceId: '{resourceId}' and Control: '{control}'");

            var reportData = await _controlReportService.GetDataAsync(platform, resourceId, control);

            if (reportData == null)
            {
                _logger.LogError($"No Data found for Platform: '{platform}', ResourceId: '{resourceId}' and Control: '{control}'");
                return NotFound();
            }

            var latestControl = reportData.Controls.OrderByDescending(c => c.Date)
                .First();

            return Ok(latestControl);

        }
    }
}
