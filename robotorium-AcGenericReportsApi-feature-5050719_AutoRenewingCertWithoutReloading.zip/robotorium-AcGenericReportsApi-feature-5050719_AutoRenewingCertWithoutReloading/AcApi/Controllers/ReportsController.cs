﻿using AcApi.Adapters;
using AcApi.Services;
using AcGenericReports.Models;
using Microsoft.AspNetCore.Authentication.Certificate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static System.Net.WebRequestMethods;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AcApi.Controllers
{

    [ApiController] // anotation
    [Route("api/[controller]")] // routering, waar gaat de call naar toe
    [Authorize(AuthenticationSchemes = CertificateAuthenticationDefaults.AuthenticationScheme)]
    public class ReportsController : ControllerBase
    {
        private readonly IControlReportService _controlReportService;
        private readonly ILogger<ReportsController> _logger;

        public ReportsController(IControlReportService controlReportService, 
                                 ILogger<ReportsController> logger)
        {
            _controlReportService = controlReportService;
            _logger = logger;
        }

        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status204NoContent)] // of de responce goed is gegaan 204 NoContent
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Post([FromBody]ControlReportDTO controlReportDTO) // Dit endpoint accepteert alleen een ControlReportDTO object
        {
            _logger.LogInformation($"Processing Data for Platform: '{controlReportDTO.Platform}', ResourceId: '{controlReportDTO.ResourceId}' and Control: '{controlReportDTO.Control}'");

            await _controlReportService.ProcessDataAsync(controlReportDTO);

            return NoContent();
        }

    }

}

