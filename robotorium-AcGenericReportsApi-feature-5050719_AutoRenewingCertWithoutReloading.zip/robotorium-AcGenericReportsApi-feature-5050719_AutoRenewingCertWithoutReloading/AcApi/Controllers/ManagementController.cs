﻿using AcApi.Models;
using AcApi.Services;
using Microsoft.AspNetCore.Authentication.Certificate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(AuthenticationSchemes = CertificateAuthenticationDefaults.AuthenticationScheme)]
    public class ManagementController : ControllerBase
    {
        private readonly CertificateValidationService _validationService;

        public ManagementController(CertificateValidationService validationService)
        {
            _validationService = validationService;
        }

        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Policy = "ApiAdmin")]
        public IActionResult AddConsumer([FromBody] AllowedCert allowedCert)
        {
            if (allowedCert == null)
            {
                return BadRequest("AllowedCert object is null");
            }

            // Logica om de CN toe te voegen


            return Ok("CN succesvol toegevoegd");
        }
    }
}
