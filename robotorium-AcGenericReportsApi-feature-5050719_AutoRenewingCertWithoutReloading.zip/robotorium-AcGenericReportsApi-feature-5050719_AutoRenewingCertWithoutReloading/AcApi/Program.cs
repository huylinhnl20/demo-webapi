using AcApi.Adapters;
using AcApi.Extensions;
using AcApi.Models;
using AcApi.Services;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

builder.AddServiceDefaults();

string certPath = Environment.GetEnvironmentVariable("ASPNETCORE_Kestrel__Certificates__Default__Path")!;
string certPassword = Environment.GetEnvironmentVariable("ASPNETCORE_Kestrel__Certificates__Default__Password")!;

builder.ConfigureKestrelWithCertificate(certPath, certPassword);

//builder.Services.Configure<KestrelServerOptions>(options =>
//{
//    options.ConfigureHttpsDefaults(options =>
//        options.ClientCertificateMode = ClientCertificateMode.AllowCertificate);
//});

// Add services to the container.
builder.Services.AddOptions();
builder.Services.Configure<CertOptions>(builder.Configuration.GetSection("CertOptions"));
builder.Services.ConfigureClientCertAuthentication();
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IControlReportService,ControlReportService>();
builder.Services.AddSingleton<IStorageAdapter, StorageAdapter>();

var app = builder.Build();

app.MapDefaultEndpoints();

if (app.Environment.IsDevelopment()) // Swagger beschikbaar maken voor development 
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCertificateForwarding();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
