﻿using AcGenericReports.Models;
using System.Text.Json;

namespace AcApi.Adapters
{
    public class StorageAdapter : IStorageAdapter
    {
        private readonly ILogger<IStorageAdapter> _logger;
        
        public StorageAdapter(ILogger<IStorageAdapter> logger)
        {
            _logger = logger;
        }

        public async Task WriteData(ControlReportCollection controlReportCollection)
        {
            string jsonContent = JsonSerializer.Serialize(controlReportCollection);

            string filePath = this.FilePath(controlReportCollection.Platform, controlReportCollection.ResourceId, controlReportCollection.Control);

            CreatePath(filePath);

            // Schrijf de JSON naar het bestand
            await File.WriteAllTextAsync(filePath, jsonContent);
            _logger.LogInformation($"Saving data to: '{filePath}'");
        }

        public async Task<ControlReportCollection> ReadData(string Platform, string ResourceId, int Control)
        {

            string filePath = this.FilePath(Platform, ResourceId, Control);

            if (File.Exists(filePath))
            {
                _logger.LogInformation($"File exists, reading data: '{filePath}'");

                var ResolvedControlReportData = JsonSerializer.Deserialize<ControlReportCollection>(await File.ReadAllTextAsync(filePath));

                return ResolvedControlReportData!;
            }
            _logger.LogError($"File does not exists: '{filePath}'");

            return null!;
        }

        public void CreatePath(string filePath)
        {
            string directory = Path.GetDirectoryName(filePath)!;
            if (!Directory.Exists(directory))
            {
                _logger.LogInformation($"Creating directory for Platform '{directory}'");
                Directory.CreateDirectory(directory);
            }
        }

        public string FilePath(string Platform, string ResourceId, int Control)
        {
            string storageLocation = Path.Combine(Environment.GetEnvironmentVariable("STORAGE_LOC")!, Platform);
            string filename = $"{ResourceId}-{Control}.json";
            string filePath = Path.Combine(storageLocation, filename);

            return filePath;
        }

    }
}