﻿
using AcGenericReports.Models;

namespace AcApi.Adapters
{
    public interface IStorageAdapter
    {
        Task WriteData(ControlReportCollection controlReportDTO);
        Task<ControlReportCollection> ReadData(string Platform, string ResourceId, int Control);
    }
}

