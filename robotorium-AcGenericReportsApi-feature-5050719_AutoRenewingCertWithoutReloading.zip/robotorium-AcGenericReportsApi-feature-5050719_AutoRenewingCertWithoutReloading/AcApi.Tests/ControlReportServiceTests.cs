﻿using AcApi.Adapters;
using AcApi.Services;
using AcGenericReports.Models;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcApi.Tests
{
    public class ControlReportServiceTests
    {
        [Fact]
        public void ControlDTOGenerationWithTodaysDate()
        {
            var reportCollection = new ControlReportCollection("test", "test", 1);
            
            var mock = new Mock<IStorageAdapter>();
            mock.Setup(m => m.WriteData(It.IsAny<ControlReportCollection>()))
                .Callback<ControlReportCollection>(c => reportCollection = c)
                .Returns(() => Task.CompletedTask);

            var logMock = new Mock<ILogger<ControlReportService>>();

            var service = new ControlReportService(mock.Object, logMock.Object);

            var inputDTO = new ControlReportDTO
            {
                Control = 1,
                Platform = "Test",
                Status = ControlStatus.Compliant,
                ResourceId = "Test",
                Info = "Test object",
            };

            //act
            service.ProcessDataAsync(inputDTO);

            //Assert
            Assert.Equal(1, reportCollection.Controls.Count);
            Assert.Equal(DateOnly.FromDateTime(DateTime.Today), reportCollection.Controls.First().Date);
        }

        [Fact]
        public void StorageProviderReadsData()
        {
            var inputDTO = new ControlReportDTO
            {
                Control = 1,
                Platform = "Test",
                Status = ControlStatus.Compliant,
                ResourceId = "Test",
                Info = "Test object",
            };

            var mock = new Mock<IStorageAdapter>();
            mock.Setup(m => m.ReadData("Test", "Test", 1))
            .Verifiable();

            var logMock = new Mock<ILogger<ControlReportService>>();

            var service = new ControlReportService(mock.Object, logMock.Object);
            service.ProcessDataAsync(inputDTO);

            mock.Verify(m => m.ReadData("Test", "Test", 1), Times.AtLeastOnce());

        }        
    }
}
