﻿using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using Moq;
using Microsoft.Extensions.Configuration;
using AcApi.Services;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using AcApi.Models;

namespace AcApi.Tests
{
    public class CertificateValidationTests
    {
        [Fact]
        public void ShouldReturnAllowedCert_OnValidCert()
        {
            // Arrange
            var mockCert = CreateSelfSignedCertificate();
            var optionsMock = MockCertificateOptions("JUSTACOMMONNAME");
            var mockLogger = new Mock<ILogger<CertificateValidationService>>();
            var validationService = new CertificateValidationService(optionsMock, mockLogger.Object);

            // Act
            var result = validationService.ValidateCertificate(mockCert);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("JUSTACOMMONNAME", result.CN);
        }

        [Fact]
        public void ShouldReturnNull_OnInvalidCert()
        {
            // Arrange
            var mockCert = CreateSelfSignedCertificate();
            var optionsMock = MockCertificateOptions("SOMEFAKECOMMONNAME");

            var mockLogger = new Mock<ILogger<CertificateValidationService>>();
            var validationService = new CertificateValidationService(optionsMock, mockLogger.Object);

            // Act
            var result = validationService.ValidateCertificate(mockCert);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void IsApiAdmin_ShouldReturnTrue_WhenCertIsApiAdmin()
        {
            // Arrange
            var allowedCert = new AllowedCert
            {
                Name = "TestCert",
                CN = "CNVALUE",
                IsApiAdmin = true
            };

            var optionsMock = MockCertificateOptions("JUSTAVALUE");
            var mockLogger = new Mock<ILogger<CertificateValidationService>>();
            var validationService = new CertificateValidationService(optionsMock, mockLogger.Object);

            // Act
            var result = validationService.IsApiAdmin(allowedCert);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsApiAdmin_ShouldReturnFalse_WhenCertIsNotApiAdmin()
        {
            // Arrange
            var allowedCert = new AllowedCert
            {
                Name = "TestCert",
                CN = "CNVALUE",
                IsApiAdmin = false
            };

            var optionsMock = MockCertificateOptions("JUSTAVALUE");

            var mockLogger = new Mock<ILogger<CertificateValidationService>>();
            var validationService = new CertificateValidationService(optionsMock, mockLogger.Object);

            // Act
            var result = validationService.IsApiAdmin(allowedCert);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void IsApiAdmin_ShouldReturnFalse_WhenCertHasNoIsApiAdminValue()
        {
            // Arrange
            var allowedCert = new AllowedCert
            {
                Name = "TestCert",
                CN = "CNVALUE"
            };

            var optionsMock = MockCertificateOptions("JUSTAVALUE");
            var mockLogger = new Mock<ILogger<CertificateValidationService>>();
            var validationService = new CertificateValidationService(optionsMock, mockLogger.Object);

            // Act
            var result = validationService.IsApiAdmin(allowedCert);

            // Assert
            Assert.False(result);
        }

        private X509Certificate2 CreateSelfSignedCertificate()
        {
            string subject = "CN=JUSTACOMMONNAME, O=JUSTAORGINIZATIONNAME, L=JUSTALOCATIONNAME, S=JUSTACITYNAME, C=NL";
            var ecdsa = ECDsa.Create();
            var req = new CertificateRequest(subject, ecdsa, HashAlgorithmName.SHA256);
            X509Certificate2 cert = req.CreateSelfSigned(DateTimeOffset.Now, DateTimeOffset.Now.AddYears(5));

            return cert;
        }

        private IOptionsMonitor<CertOptions> MockCertificateOptions(string commonName)
        {
            var certList = new List<AllowedCert>();

            certList.Add(new AllowedCert { Name = "test", CN = commonName, IsApiAdmin = false });


            var certOptions = new CertOptions
            {
                AllowedCerts = certList.AsEnumerable()
            };

            var mock = new Mock<IOptionsMonitor<CertOptions>>();
            mock.SetupGet<CertOptions>(m => m.CurrentValue)
                .Returns(certOptions);

            return mock.Object;
        }

    }
}
