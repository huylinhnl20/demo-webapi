﻿using AcApi.Adapters;
using AcApi.Services;
using AcGenericReports.Models;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace AcApi.Tests
{
    public class StorageAdapterTests
    {
        [Fact]
        public void FilePathReturnsCorrectPath()
        {
            // Arrange
            var logMock = new Mock<ILogger<StorageAdapter>>();
            var storageAdapter = new StorageAdapter(logMock.Object);

            string storageLocation = "C:\\storage";
            var expected = Path.Combine(storageLocation, "PlatformA", "ResourceA-1.json");

            Environment.SetEnvironmentVariable("STORAGE_LOC", storageLocation);

            // Act
            var actualFilePath = storageAdapter.FilePath("PlatformA", "ResourceA", 1);
            // Assert
            Assert.Equal(expected, actualFilePath);
        }

    }
}
